var fs = require('fs');
var express = require('express');
var _ = require("underscore");
var request = require('request');


var app = express();
var output = [];


//Get json id

app.get('/scrape', function(req, res){

	// var obj = JSON.parse(fs.readFileSync('itunestest.json', 'utf8'));
	// console.log(obj);
	fs.readFile('itunes.json', 'utf8', function (err, data) {
	  if (err) throw err;
	  obj = JSON.parse(data);

      _.each(obj, function( item ){
      	if(!_.isEmpty(item.titlehref) && _.isString(item.titlehref)){
	      	// console.log(item.titlehref);
	      	var split = item.titlehref.split("/");
	      	var id = split[split.length-1].replace("id","");
	      	var single = {
	      		title: item.title,
	      		id: id
	      	};
	      	output.push(single);
	    }
      });

	  	fs.writeFile('output.json', JSON.stringify(output, null, 4), function(err){

	  	    console.log('File successfully written! - Check your project directory for the output.json file');

	  	});

	  	// Finally, we'll just send out a message to the browser reminding you that this app does not have a UI.
	  	res.send('Check your console!');


	});	

});

app.get('/rss', function(req, res){
	var output = [];
	// var url = getItunesUrl("260190086");
	var self = this;
	fs.readFile('output.json', 'utf8', function (err, data) {

		if (err) throw err;
		obj = JSON.parse(data);
		_.each(obj, function( item ){
			var url = getItunesUrl(item.id);
			// console.log(url);
			// console.log(output);
			request({
			    url : url,
			    rejectUnauthorized : false,
			    headers : {
			        'User-Agent' : 'Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko'
			    }
			}, function(error, response, body){
				  if (!error && response.statusCode == 200) {
				  	var obj = JSON.parse(body);
				  	if(_.isObject(obj) && _.isObject(obj.results) && _.isObject(obj.results[0]) && !_.isEmpty(obj.results[0].feedUrl) && _.isString(obj.results[0].feedUrl)){
					  	var json = { 
					  		title: item.title,
					  		rssUrl: obj.results[0].feedUrl
					  	}

					    output.push(json);
					    console.log(output);
					}
				  }

			});

		});



	  fs.writeFile('outputRss.json', JSON.stringify(output, null, 4), function(err){

	      console.log('File successfully written! - Check your project directory for the outputRss.json file');
  	  		res.send('Finish');

	  });

	});	



});

function getItunesUrl(id){
	return "https://itunes.apple.com/lookup?id="+ id +"&entity=podcast";
};


app.listen("8081");
console.log('Magic happens on port 8081');
exports = module.exports = app;
